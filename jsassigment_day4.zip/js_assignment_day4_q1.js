//question1
// By Five way we can access elements in the DOM 
// 1.getElementsByTagName
// 2.getElementsByClassName
// 3.getElementById
// 4.querySelector()
// 5.querySelectorAll()

1.getElementsByTagName
	Using tag name, we can access elements, like h1,h2,head,body.
	It gives collection of html elements.

2.getElementsByClassName
	Using class name, we can access elements. we can assign class to tag in html.
	It gives collection of html elements.

3.getElementById
	Using ID name, we can access elements. we can assign ID to tag in html.
	It gives single element.

4.querySelector()
	Using querySelector, we can access elements, That select only first matched element and give access.. if we want to access using querySelector, 
	there are three different method.
	a. for id,  document.querySelector('#name')
	b. for class, document.querySelector('.name')
	c. for tag. document.querySelector('input')

	

5.querySelectorAll()
	querySelectorAll returns all matched elements. 
	
	ex. document.querySelectorAll('.name')
		document.querySelectorAll('input')
